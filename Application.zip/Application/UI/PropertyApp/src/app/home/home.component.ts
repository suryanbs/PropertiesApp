import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  
  constructor(private httpService: HttpClient) { }

  properties: any;
  ngOnInit() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
        'Access-Control-Allow-Origin': '*'
        })
      };
    
    this.httpService.get('https://localhost:44393/api/home',httpOptions).subscribe(
      response => {
        this.properties = response;
      }
    );
    
  }
  saveProperties(event: any, row: any){
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Accept': 'application/json',
          'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
          'Access-Control-Allow-Origin': '*'
          })
        };

      this.httpService.post('https://localhost:44393/api/home',row, httpOptions).subscribe(
        response =>{
        }
      );
  }
}
