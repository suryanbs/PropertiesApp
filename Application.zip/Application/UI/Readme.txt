Steps to run the application.
1. Install node package manager to get the required middlewires. e.g npm -i
2. Run the application as ng server.