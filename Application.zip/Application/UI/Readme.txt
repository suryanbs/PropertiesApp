Steps to run the application.
1. Download latest node js e,g Node v10.13 or higher. 
2. Install node js in to your system.
3. Unzip the UI application PropertyApp. 
4. Run the following commands in PropertyApp directory. 
5. Install node package manager to get the required middlewires. e.g. npm -i
6. Run command: npm install -g @angular/cli
7. Run the application command:  ng server
8. After complile successful. Browse the UI app in  http://localhost:4200/
9. Make sure API and Database application must be running along with UI app.
