Steps to run the application.
1. Execute the script in SQL server to generate the database and tables.
2. Copy the server URL and update in API project app settings.