Steps to run the application.
1. Execute the script in SQL server to generate the database and tables.