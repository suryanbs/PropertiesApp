create database PropertiesApp
GO
USE [PropertiesApp]
GO

/****** Object:  Table [dbo].[Address]    Script Date: 30-03-21 07:40:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Address](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[address1] [varchar](200) NULL,
	[address2] [varchar](200) NULL,
	[city] [varchar](100) NULL,
	[country] [varchar](100) NULL,
	[district] [varchar](100) NULL,
	[state] [varchar](100) NULL,
	[zip] [varchar](100) NULL,
	[zip_plus4] [varchar](100) NULL,
 CONSTRAINT [PK_Address] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[Properties](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[year_built] [int] NULL,
	[list_price] [float] NULL,
	[monthly_rent] [float] NULL,
	[gross_yield] [float] NULL,
	[address_id] [int] NOT NULL,
 CONSTRAINT [PK_Properties] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Properties]  WITH CHECK ADD  CONSTRAINT [FK_Properties_Address] FOREIGN KEY([address_id])
REFERENCES [dbo].[Address] ([id])
GO

ALTER TABLE [dbo].[Properties] CHECK CONSTRAINT [FK_Properties_Address]
GO
