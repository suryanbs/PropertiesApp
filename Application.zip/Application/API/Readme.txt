
Steps to run the application.
1. Install the .NET Core2.1 to run the application.
2. Check the connection string in appsettings.json and update to the correct SQL server.
3. Check the launch settings to run in IISExpress/ Kestrel server.