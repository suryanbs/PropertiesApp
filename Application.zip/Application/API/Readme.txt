
Steps to run the application.
1. Install the .NET Core2.1 to run the application.
2. Run the database script and update the database server name in connectionstring in appsettings.json.
2. Run application in vsiualstudio using IISExpress/ Kestrel server.
3. Check the launch settings to run in IISExpress/ Kestrel server.