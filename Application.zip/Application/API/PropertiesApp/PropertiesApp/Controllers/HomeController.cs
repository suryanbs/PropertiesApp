﻿using System.Threading.Tasks;
using Domain;
using Interfaces.Services;
using Microsoft.AspNetCore.Mvc;

namespace PropertiesApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly IHomeService _homeService;

        public HomeController(IHomeService homeService)
        {
            _homeService = homeService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var result = await _homeService.GetProperties();

            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Post(PropertyDto property)
        {
            var result = await _homeService.SaveProperties(property);

            if (!result)
            {
                return StatusCode(500, "error occured while saving property!");
            }

            return Ok("Successfully saved!!");
        }
    }
}