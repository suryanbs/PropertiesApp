﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    public class Address
    {
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string country { get; set; }
        public string county { get; set; }
        public object district { get; set; }
        public string state { get; set; }
        public string zip { get; set; }
        public string zipPlus4 { get; set; }
    }

    public class Financial
    {
        public double listPrice { get; set; }
       
        public double monthlyRent { get; set; }
       
    }

    public class Physical
    {
      
        public int yearBuilt { get; set; }
      
    }

    public class Property
    {
        public Address address { get; set; }
        public Financial financial { get; set; }
        public Physical physical { get; set; }
       
    }

    public class Root
    {
        public List<Property> properties { get; set; }
    }
}
