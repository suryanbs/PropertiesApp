﻿using System.Collections.Generic;

namespace Domain
{
    public class PropertyDto
    {
        public AddressDto Address { get; set; }
        public int? YearBuilt { get; set; }
        public double? ListPrice { get; set; }
        public double? MonthlyRent { get; set; }
        public double? GrossYield { get; set; }
    }
}
