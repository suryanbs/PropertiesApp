﻿namespace Domain
{
    public class AddressDto
    {
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string country { get; set; }
        public string county { get; set; }
        public object district { get; set; }
        public string state { get; set; }
        public string zip { get; set; }
        public string zipPlus4 { get; set; }

        public static AddressDto ConvertToDto(Address address)
        {
            return new AddressDto
            {
                address1 = address.address1,
                address2 = address.address2 ?? string.Empty,
                city = address.city,
                country = address.country,
                county = address.county ?? string.Empty,
                district = address.district??string.Empty,
                state = address.state,
                zip = address.zip,
                zipPlus4 = address.zipPlus4
            };
        }
    }
}
