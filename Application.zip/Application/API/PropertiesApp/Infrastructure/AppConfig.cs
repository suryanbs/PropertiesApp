﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Extensions.Configuration;


namespace Infrastructure
{
    public class AppConfig
    {
        private static IConfiguration Configuration;
        static AppConfig()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            Configuration = builder.Build();
        }

        public static IConfigurationSection Get(string name)
        {
            IConfigurationSection appSettings = Configuration.GetSection(name);
            return appSettings;
        }

        public static IConfiguration GetConfiguration()
        {
            return Configuration;
        }
    }
}
