﻿using System;
using System.Collections.Generic;

namespace Infrastructure.EFModels
{
    public partial class Properties
    {
        public int Id { get; set; }

        public int? YearBuilt { get; set; }

        public double? ListPrice { get; set; }
        public double? MonthlyRent { get; set; }
        public double? GrossYield { get; set; }
        public int AddressId { get; set; }

        public Address Address { get; set; }
    }
}
