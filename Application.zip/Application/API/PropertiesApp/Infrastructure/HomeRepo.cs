﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Domain;
using Infrastructure.EFModels;
using Interfaces.Repositories;
using Newtonsoft.Json;
//using Address = Domain.Address;
using EFModels = Infrastructure.EFModels;

namespace Infrastructure
{
    public class HomeRepo : IHomeRepo
    {
        private readonly IHttpClientFactory _clientFactory;

        public HomeRepo(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        // TODO: Read the Url in service  and pass to the repo method
        public async Task<List<PropertyDto>> GetProperties()
        {
            // TODO: Read the URL from appsettings.json

            var url = AppConfig.Get("MySettings")["DataUrl"];

            var request = new HttpRequestMessage(HttpMethod.Get, url);
                

            var client = _clientFactory.CreateClient();

            var response = await client.SendAsync(request);

            // Use using and solve the issue
            var stringContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var res = JsonConvert.DeserializeObject<Root>(stringContent);

            List < PropertyDto> list = ConvertJsontoProperty(res);
            return list;
        }

        private List<PropertyDto> ConvertJsontoProperty(Root response)
        {
            List<PropertyDto> dto = new List<PropertyDto>() { };
            foreach (var data in response.properties)
            {
                dto.Add(new PropertyDto()
                {
                    ListPrice = data.financial?.listPrice,
                    MonthlyRent = data.financial?.monthlyRent,
                    GrossYield = data.financial?.monthlyRent * 12/ data.financial?.listPrice,
                    YearBuilt = data.physical?.yearBuilt,
                    Address =  AddressDto.ConvertToDto(data.address)
                });
            }

            return dto;
        }

        public async Task<bool> SaveProperties(PropertyDto property)
        {
            try
            {
                using (var context = new PropertiesAppContext())
                {
                    var addrs = new EFModels.Address
                    {
                        Address1 = property.Address.address1,
                        Address2 = property.Address.address2,
                        City = property.Address.city,
                        Country = property.Address.country,
                        District = property.Address.district?.ToString(),
                        State = property.Address.state,
                        Zip = property.Address.zip,
                        ZipPlus4 = property.Address.zipPlus4
                    };
                    context.Address.Add(addrs);

                    context.Properties.Add(new EFModels.Properties
                    {
                        YearBuilt = property.YearBuilt,
                        MonthlyRent = property.MonthlyRent,
                        GrossYield = property.GrossYield,
                        ListPrice = property.ListPrice,
                        AddressId = addrs.Id

                    });

                    await context.SaveChangesAsync();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
