﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Domain;

namespace Interfaces.Repositories
{
    public interface IHomeRepo
    {
        Task<List<PropertyDto>> GetProperties();
        Task<bool> SaveProperties(PropertyDto property);

    }
}
