﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Domain;

namespace Interfaces.Services
{
    public interface IHomeService
    {
        Task<List<PropertyDto>> GetProperties();
        Task<bool> SaveProperties(PropertyDto property);
    }
}
