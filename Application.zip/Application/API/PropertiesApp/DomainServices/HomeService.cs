﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain;
using Interfaces.Repositories;
using Interfaces.Services;

namespace DomainServices
{
    public class HomeService : IHomeService
    {
        private readonly IHomeRepo _repo;

        public HomeService(IHomeRepo repo)
        {
            _repo = repo;
        }

        public async Task<List<PropertyDto>> GetProperties()
        {
           
                return await _repo.GetProperties();

        }

        public Task<bool> SaveProperties(PropertyDto property)
        {
           var isSaved = _repo.SaveProperties(property);

            return isSaved;
        }
    }
}
